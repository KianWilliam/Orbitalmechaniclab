<?php 
/*
  * @package component orbitalmechaniclab for Joomla! 5.x 6.x
 * @version $Id: orbitalmechaniclab 1.0.0 2026-05-05 01:10:10Z $
 * @author KWProductions Co.
 * @copyright (C) 2022- KWProductions Co.
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 
 This file is part of orbitalmechaniclab.
    orbitalmechaniclab is free software: you can redistribute it and/or adify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    orbitalmechaniclab is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for are details.
    You should have received a copy of the GNU General Public License
    along with orbitalmechaniclab.  If not, see <http://www.gnu.org/licenses/>.
 
*/

?>
<?php
/**
 * @package     com_orbitalmechaniclab
 * @version     1.0.0
 * @copyright   Copyright (C) 2025. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      KWProductions Co. <webarchitect@kwproductions121.ir> - https://componentgenerator.com
 */

namespace KWP121\Component\Orbitalmechaniclab\Site\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\BaseController;

/**
 * Base controller class
 *
 * @since  3.1
 */
class DisplayController extends BaseController
{
    /**
     * Method to display a view
     *
     * @param boolean $cachable If true, the view output will be cached
     * @param mixed|boolean $urlparams An array of safe URL parameters and their
     *                                     variable types, for valid values see {@link \JFilterInput::clean()}.
     *
     * @return JControllerLegacy|BaseController
     *
     * @throws Exception
     * @since   3.1
     */
	public function display($cachable = false, $urlparams = false)
	{
		$user = Factory::getUser();

		// Set the default view name and format from the Request
		$vName = $this->input->get('view', 'Orbitalmechaniclabs');
		$this->input->set('view', $vName);

		if ($user->get('id') || ($this->input->getMethod() === 'POST' && $vName === 'Orbitalmechaniclabs')) {
			$cachable = false;
		}

		$safeurlparams = array(
			'id'               => 'ARRAY',
			'type'             => 'ARRAY',
			'limit'            => 'UINT',
			'limitstart'       => 'UINT',
			'filter_order'     => 'CMD',
			'filter_order_Dir' => 'CMD',
			'lang'             => 'CMD'
		);

        Factory::getLanguage()->load('com_orbitalmechaniclab', JPATH_ADMINISTRATOR, 'en-GB', true);

		return parent::display($cachable, $safeurlparams);
	}
}
